﻿using System;
using System.Threading;
using WebSocketSharp;
using WebSocketSharp.Net;
using WebSocketSharp.Server;
using System.Threading.Tasks;
using vtortola.WebSockets;

namespace WindowsFormsApp3
{
    public class WebSocketHandler
    {
        private CancellationTokenSource cancellation;

        public void WebSocketHandler()
        {
        }

        public void start()
        {
            cancellation = new CancellationTokenSource();
            var endpoint = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 1818);
            WebSocketListener server = new WebSocketListener(endpoint);
            var rfc6455 = new vtortola.WebSockets.Rfc6455.WebSocketFactoryRfc6455(server);
            server.Standards.RegisterStandard(rfc6455);
            server.Start();
            var task = Task.Run(() => AcceptWebSocketClientsAsync(server, cancellation.Token));

        }

        public void stop()
        {
            cancellation.Cancel();
            var task = Task.Run(() => AcceptWebSocketClientsAsync(server, cancellation.Token));
            task.Wait();

        }
        public async Task AcceptWebSocketClientsAsync(WebSocketListener server, CancellationToken token)
        {
            while (!token.IsCancellationRequested)
            {
                try
                {
                    //클라이언트가 들어왔을까요?
                    var ws = await server.AcceptWebSocketAsync(token).ConfigureAwait(false);

                    //소켓이 null 이 아니면, 핸들러를 스타트 합니다.(또 다른 친구가 들어올 수도 있으니 비동기로...)
                    if (ws != null)
                        Task.Run(() => HandleConnectionAsync(ws, token));
                }
                catch (Exception aex)
                {
                    Console.WriteLine("Error Accepting clients: " + aex.GetBaseException().Message);
                }
            }
        }

        static async Task HandleConnectionAsync(WebSocket ws, CancellationToken cancellation)
        {
            try
            {
                //연결이 끊기지 않았고, 캔슬이 들어오지 않는 한 루프를 돕니다.
                while (ws.IsConnected && !cancellation.IsCancellationRequested)
                {
                    //클라이언트로부터 메시지가 왔는지 비동기로 읽어요.
                    String msg = await ws.ReadStringAsync(cancellation).ConfigureAwait(false);

                    //읽은 메시지가 null 이 아니면, 뭔가를 처리 합니다. 이 코드는 그냥 ack 라고 에코를 보내도록 만들었습니다.
                    if (msg != null)
                        ws.WriteString("ack : " + msg);
                }
            }
            catch (Exception aex)
            {
                Console.WriteLine("Error Handling connection: " + aex.GetBaseException().Message);
                try { ws.Close(); }
                catch { }
            }
            finally
            {
                //소켓은 Dispose 해 줍니다.
                ws.Dispose();
            }
        }

    }

}
